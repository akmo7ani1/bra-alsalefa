package com.example.braalsalfa

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var socket: Socket
    private lateinit var startGameButton: Button
    private lateinit var playersStatusTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        socket = IO.socket("http://192.168.1.XXX:3000") // استبدل بالـ IP الخاص بالخادم
        socket.connect()

        startGameButton = findViewById(R.id.startGameButton)
        playersStatusTextView = findViewById(R.id.playersStatusTextView)

        startGameButton.setOnClickListener {
            socket.emit("startGame", "بدأت اللعبة!")
        }

        socket.on("playerResponse") { data ->
            val playerData = JSONObject(data[0].toString())
            runOnUiThread {
                playersStatusTextView.append("${playerData.getString("name")}: ${playerData.getString("response")}
")
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        socket.disconnect()
    }
}
