package com.example.braalsalfa

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject

class PlayerActivity : AppCompatActivity() {
    private lateinit var socket: Socket
    private lateinit var wordTextView: TextView
    private lateinit var clickButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        socket = IO.socket("http://192.168.1.XXX:3000")
        socket.connect()

        wordTextView = findViewById(R.id.wordTextView)
        clickButton = findViewById(R.id.clickButton)

        socket.on("newWord") { data ->
            val word = data[0].toString()
            runOnUiThread {
                wordTextView.text = word
            }
        }

        clickButton.setOnClickListener {
            socket.emit("playerResponse", JSONObject().apply {
                put("name", "اللاعب 1")
                put("response", "نقرة سريعة!")
            })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        socket.disconnect()
    }
}
